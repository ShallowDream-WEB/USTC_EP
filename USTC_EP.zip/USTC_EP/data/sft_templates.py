"""SFT Few-Shot 模板：覆盖三种工具的各种使用场景。

设计原则：
- 每条模板展示完整的 ReAct 推理过程
- 覆盖 calculator / python_exec / sympy 三种工具
- 涵盖基础运算、多步推理、错误恢复、最终答案输出
"""

from typing import Any, Dict, List

FEW_SHOT_TEMPLATES: List[Dict[str, Any]] = [
    # ============================================================
    # 模板 1: 基础 calculator 用法 — 一步计算
    # ============================================================
    {
        "messages": [
            {
                "role": "user",
                "content": "问题：计算 156 * 23 的结果。",
            },
            {
                "role": "assistant",
                "content": 'Thought: 这是一道简单乘法，直接使用 calculator 计算。\n\n<tool_call>{"name": "calculator", "args": {"expression": "156 * 23"}}</tool_call>\n\nObserved: 3588\n\nThought: 计算结果是 3588，即为最终答案。\n\n<answer>3588</answer>',
            },
        ],
    },

    # ============================================================
    # 模板 2: 多步 calculator — 加减复合
    # ============================================================
    {
        "messages": [
            {
                "role": "user",
                "content": "问题：小明有 120 元，花了 35 元买书，又赚了 68 元，最后花了 42 元。还剩多少钱？",
            },
            {
                "role": "assistant",
                "content": 'Thought: 需要逐步计算。先算花35元后剩余：120 - 35 = 85。\n\n<tool_call>{"name": "calculator", "args": {"expression": "120 - 35"}}</tool_call>\n\nObserved: 85\n\nThought: 再算赚了68元后：85 + 68 = 153。\n\n<tool_call>{"name": "calculator", "args": {"expression": "85 + 68"}}</tool_call>\n\nObserved: 153\n\nThought: 最后花42元：153 - 42 = 111。\n\n<tool_call>{"name": "calculator", "args": {"expression": "153 - 42"}}</tool_call>\n\nObserved: 111\n\nThought: 最终剩余 111 元。\n\n<answer>111</answer>',
            },
        ],
    },

    # ============================================================
    # 模板 3: 计算器幂运算和开方
    # ============================================================
    {
        "messages": [
            {
                "role": "user",
                "content": "问题：计算 2 的 10 次方，然后对结果开平方根。",
            },
            {
                "role": "assistant",
                "content": 'Thought: 先计算 2^10。\n\n<tool_call>{"name": "calculator", "args": {"expression": "2 ** 10"}}</tool_call>\n\nObserved: 1024\n\nThought: 再对 1024 开平方根。\n\n<tool_call>{"name": "calculator", "args": {"expression": "sqrt(1024)"}}</tool_call>\n\nObserved: 32.0\n\nThought: 结果是 32。\n\n<answer>32</answer>',
            },
        ],
    },

    # ============================================================
    # 模板 4: 分数运算 — 用 python_exec
    # ============================================================
    {
        "messages": [
            {
                "role": "user",
                "content": "问题：计算 3/4 + 5/6 - 1/3 的结果，以最简分数表示。",
            },
            {
                "role": "assistant",
                "content": 'Thought: 分数运算用手算容易出错，用 Python 的 fractions 模块精确计算。\n\n<tool_call>{"name": "python_exec", "args": {"code": "from fractions import Fraction\\nresult = Fraction(3, 4) + Fraction(5, 6) - Fraction(1, 3)\\nprint(result)"}}</tool_call>\n\nObserved: 5/4\n\nThought: 结果是 5/4。\n\n<answer>5/4</answer>',
            },
        ],
    },

    # ============================================================
    # 模板 5: 统计计算 — python_exec
    # ============================================================
    {
        "messages": [
            {
                "role": "user",
                "content": "问题：一组数据：12, 18, 23, 15, 28, 32, 19。求这组数据的平均值和中位数。",
            },
            {
                "role": "assistant",
                "content": 'Thought: 使用 Python 的 statistics 模块计算平均值和中位数。\n\n<tool_call>{"name": "python_exec", "args": {"code": "import statistics\\ndata = [12, 18, 23, 15, 28, 32, 19]\\nmean_val = statistics.mean(data)\\nmedian_val = statistics.median(data)\\nprint(f\'mean={mean_val}, median={median_val}\')"}}</tool_call>\n\nObserved: mean=21, median=19\n\nThought: 平均值是21，中位数是19。\n\n<answer>平均值21，中位数19</answer>',
            },
        ],
    },

    # ============================================================
    # 模板 6: 排列组合 — python_exec + math
    # ============================================================
    {
        "messages": [
            {
                "role": "user",
                "content": "问题：从 10 个人中选 3 个人组成一个小组，有多少种选法？",
            },
            {
                "role": "assistant",
                "content": 'Thought: 这是组合问题 C(10,3)，用 Python 计算。\n\n<tool_call>{"name": "python_exec", "args": {"code": "import math\\nresult = math.comb(10, 3)\\nprint(result)"}}</tool_call>\n\nObserved: 120\n\nThought: C(10,3) = 120 种选法。\n\n<answer>120</answer>',
            },
        ],
    },

    # ============================================================
    # 模板 7: SymPy 解一元二次方程
    # ============================================================
    {
        "messages": [
            {
                "role": "user",
                "content": "问题：求解方程 x^2 - 5x + 6 = 0 的根。",
            },
            {
                "role": "assistant",
                "content": 'Thought: 用 SymPy 求解这个二次方程。\n\n<tool_call>{"name": "sympy", "args": {"code": "x = symbols(\'x\')\\neq = Eq(x**2 - 5*x + 6, 0)\\nsolutions = solve(eq, x)\\nprint(solutions)"}}</tool_call>\n\nObserved: [2, 3]\n\nThought: 方程的两个根是 2 和 3。\n\n<answer>x = 2 或 x = 3</answer>',
            },
        ],
    },

    # ============================================================
    # 模板 8: SymPy 因式分解
    # ============================================================
    {
        "messages": [
            {
                "role": "user",
                "content": "问题：将多项式 x^4 - 16 因式分解。",
            },
            {
                "role": "assistant",
                "content": 'Thought: 用 SymPy 的 factor 函数进行因式分解。\n\n<tool_call>{"name": "sympy", "args": {"code": "x = symbols(\'x\')\\nresult = factor(x**4 - 16)\\nprint(result)"}}</tool_call>\n\nObserved: (x - 2)*(x + 2)*(x**2 + 4)\n\nThought: 因式分解结果如上。\n\n<answer>(x-2)(x+2)(x^2+4)</answer>',
            },
        ],
    },

    # ============================================================
    # 模板 9: SymPy 求导
    # ============================================================
    {
        "messages": [
            {
                "role": "user",
                "content": "问题：求函数 f(x) = x^3 + 2x^2 - 5x + 1 的导数。",
            },
            {
                "role": "assistant",
                "content": 'Thought: 使用 SymPy 的 diff 函数对多项式求导。\n\n<tool_call>{"name": "sympy", "args": {"code": "x = symbols(\'x\')\\nf = x**3 + 2*x**2 - 5*x + 1\\nderivative = diff(f, x)\\nprint(derivative)"}}</tool_call>\n\nObserved: 3*x**2 + 4*x - 5\n\nThought: 导数计算完成。\n\n<answer>3x^2 + 4x - 5</answer>',
            },
        ],
    },

    # ============================================================
    # 模板 10: SymPy 解方程组
    # ============================================================
    {
        "messages": [
            {
                "role": "user",
                "content": "问题：解方程组：2x + y = 10, x - y = 1。",
            },
            {
                "role": "assistant",
                "content": 'Thought: 用 SymPy 求解二元一次方程组。\n\n<tool_call>{"name": "sympy", "args": {"code": "x, y = symbols(\'x y\')\\neq1 = Eq(2*x + y, 10)\\neq2 = Eq(x - y, 1)\\nsolutions = solve((eq1, eq2), (x, y))\\nprint(solutions)"}}</tool_call>\n\nObserved: {x: 11/3, y: 8/3}\n\nThought: 方程组的解为 x = 11/3, y = 8/3。\n\n<answer>x = 11/3, y = 8/3</answer>',
            },
        ],
    },

    # ============================================================
    # 模板 11: 先 SymPy 求表达式 再 calculator 数值验证
    # ============================================================
    {
        "messages": [
            {
                "role": "user",
                "content": "问题：当 x=3 时，求 (x^2 + 2x - 1) * (x - 4) 的值。",
            },
            {
                "role": "assistant",
                "content": 'Thought: 先代入 x=3 到表达式，然后用 calculator 计算数值。先展开表达式看看是否可化简：用 SymPy 代入。\n\n<tool_call>{"name": "sympy", "args": {"code": "x = symbols(\'x\')\\nexpr = (x**2 + 2*x - 1) * (x - 4)\\nresult = expr.subs(x, 3)\\nprint(result)"}}</tool_call>\n\nObserved: -14\n\nThought: 结果为 -14。再用 calculator 验证一下：3^2=9, 9+6-1=14, 14*(-1)=-14。\n\n<tool_call>{"name": "calculator", "args": {"expression": "(3**2 + 2*3 - 1) * (3 - 4)"}}</tool_call>\n\nObserved: -14\n\nThought: 两种方法结果一致，答案为 -14。\n\n<answer>-14</answer>',
            },
        ],
    },

    # ============================================================
    # 模板 12: python_exec 遍历枚举
    # ============================================================
    {
        "messages": [
            {
                "role": "user",
                "content": "问题：找出 1 到 100 之间所有能被 3 整除但不能被 5 整除的数的和。",
            },
            {
                "role": "assistant",
                "content": 'Thought: 用 Python 遍历 1-100 并筛选条件，然后求和。\n\n<tool_call>{"name": "python_exec", "args": {"code": "nums = [n for n in range(1, 101) if n % 3 == 0 and n % 5 != 0]\\nresult = sum(nums)\\nprint(f\'count={len(nums)}, sum={result}\')"}}</tool_call>\n\nObserved: count=27, sum=1221\n\nThought: 共 27 个数满足条件，它们的和为 1221。\n\n<answer>1221</answer>',
            },
        ],
    },

    # ============================================================
    # 模板 13: 多步混合 — calculator + sympy
    # ============================================================
    {
        "messages": [
            {
                "role": "user",
                "content": "问题：求多项式 x^2 + 3x + 2 在 x=5 处的值，并判断结果是否为质数。",
            },
            {
                "role": "assistant",
                "content": 'Thought: 第一步：代入 x=5 计算多项式值。\n\n<tool_call>{"name": "calculator", "args": {"expression": "5**2 + 3*5 + 2"}}</tool_call>\n\nObserved: 42\n\nThought: 多项式在 x=5 处值为 42。第二步：判断 42 是否为质数。42 = 2*3*7，不是质数（大于1且有多个因子）。\n\n<tool_call>{"name": "python_exec", "args": {"code": "import sympy\\nresult = sympy.isprime(42)\\nprint(result)"}}</tool_call>\n\nObserved: False\n\nThought: 42 不是质数。\n\n<answer>值为42，不是质数</answer>',
            },
        ],
    },

    # ============================================================
    # 模板 14: 工具调用后推理继续 — 分析型答案
    # ============================================================
    {
        "messages": [
            {
                "role": "user",
                "content": "问题：一个长方形花园的长是 15 米，宽是 8 米。如果要在周围修一条 1 米宽的路，路的面积是多少？",
            },
            {
                "role": "assistant",
                "content": 'Thought: 加上路后，外边界长为 15+2=17m，宽为 8+2=10m。路的面积 = 外长方形面积 - 内长方形面积。\n\n<tool_call>{"name": "calculator", "args": {"expression": "17 * 10 - 15 * 8"}}</tool_call>\n\nObserved: 50\n\nThought: 路的面积是 50 平方米。验证：外面积=170, 内面积=120, 差=50。\n\n<answer>50</answer>',
            },
        ],
    },

    # ============================================================
    # 模板 15: 处理带 LaTeX 的数学题 — 逐步推理
    # ============================================================
    {
        "messages": [
            {
                "role": "user",
                "content": "问题：计算 \\sqrt{256} + 3^4 - 15 \\times 2 的值。",
            },
            {
                "role": "assistant",
                "content": 'Thought: 分步计算：sqrt(256)、3^4、15*2，然后组合。\n\n<tool_call>{"name": "calculator", "args": {"expression": "sqrt(256) + 3**4 - 15 * 2"}}</tool_call>\n\nObserved: 67.0\n\nThought: 一步算出结果为 67。验证：sqrt(256)=16, 3^4=81, 15*2=30, 16+81-30=67。\n\n<answer>67</answer>',
            },
        ],
    },

    # ============================================================
    # 模板 16: 增长率 / 百分比问题
    # ============================================================
    {
        "messages": [
            {
                "role": "user",
                "content": "问题：一件商品原价 250 元，先涨价 20%，再打 8 折出售。最终售价是多少？",
            },
            {
                "role": "assistant",
                "content": 'Thought: 先计算涨价后的价格：250 * 1.2 = 300。再计算打8折：300 * 0.8 = 240。\n\n<tool_call>{"name": "calculator", "args": {"expression": "250 * 1.2 * 0.8"}}</tool_call>\n\nObserved: 240.0\n\nThought: 最终售价 240 元。\n\n<answer>240</answer>',
            },
        ],
    },

    # ============================================================
    # 模板 17: SymPy 积分
    # ============================================================
    {
        "messages": [
            {
                "role": "user",
                "content": "问题：计算定积分 ∫₀¹ (3x² + 2x) dx。",
            },
            {
                "role": "assistant",
                "content": 'Thought: 用 SymPy 计算定积分。\n\n<tool_call>{"name": "sympy", "args": {"code": "x = symbols(\'x\')\\nf = 3*x**2 + 2*x\\nresult = integrate(f, (x, 0, 1))\\nprint(result)"}}</tool_call>\n\nObserved: 2\n\nThought: 积分结果为 2。验证：∫3x²dx=x³, ∫2xdx=x², 代入上下限：(1+1)-(0+0)=2。\n\n<answer>2</answer>',
            },
        ],
    },

    # ============================================================
    # 模板 18: python_exec 数列求和
    # ============================================================
    {
        "messages": [
            {
                "role": "user",
                "content": "问题：求前 50 个正整数的平方和：1² + 2² + ... + 50²。",
            },
            {
                "role": "assistant",
                "content": 'Thought: 用 Python 计算 1 到 50 的平方和。\n\n<tool_call>{"name": "python_exec", "args": {"code": "n = 50\\nsum_of_squares = n * (n + 1) * (2 * n + 1) // 6\\nprint(sum_of_squares)"}}</tool_call>\n\nObserved: 42925\n\nThought: 使用公式 n(n+1)(2n+1)/6 计算得到 42925。\n\n<answer>42925</answer>',
            },
        ],
    },

    # ============================================================
    # 模板 19: 最大公约数 / 最小公倍数
    # ============================================================
    {
        "messages": [
            {
                "role": "user",
                "content": "问题：求 144 和 180 的最大公约数和最小公倍数。",
            },
            {
                "role": "assistant",
                "content": 'Thought: 用 Python 的 math.gcd 和 lcm 计算。\n\n<tool_call>{"name": "python_exec", "args": {"code": "import math\\ngcd = math.gcd(144, 180)\\nlcm = math.lcm(144, 180)\\nprint(f\'gcd={gcd}, lcm={lcm}\')"}}</tool_call>\n\nObserved: gcd=36, lcm=720\n\nThought: 最大公约数 36，最小公倍数 720。\n\n<answer>GCD=36, LCM=720</answer>',
            },
        ],
    },

    # ============================================================
    # 模板 20: 多步推理 + 条件判断
    # ============================================================
    {
        "messages": [
            {
                "role": "user",
                "content": "问题：一个两位数，十位数是 3，个位数比十位数大 5，这个数乘以 6 是多少？",
            },
            {
                "role": "assistant",
                "content": 'Thought: 十位数=3，个位数=3+5=8，所以这个数是 38。然后 38 * 6 = 228。\n\n<tool_call>{"name": "calculator", "args": {"expression": "38 * 6"}}</tool_call>\n\nObserved: 228\n\nThought: 结果是 228。\n\n<answer>228</answer>',
            },
        ],
    },
]


def get_templates() -> List[Dict[str, Any]]:
    """获取所有 few-shot 模板。"""
    return FEW_SHOT_TEMPLATES
